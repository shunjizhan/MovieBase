CS143 Database Project 1A

In this project we have learnt how to build a specific database, load data from database, and learnt how to extract data from database using mysql queries. We also build a web interface for users to input queries and see the results using PHP.

First, we set up the system on virtual box and set up the shared folder to easily manage files.

Second, we intialize the database and create the tables(Movie table, Actor table, etc.) for provided data.

Third, we load and query the dataset.

Next, we create a web interface using php. Users can access it from http://localhost:1438/~cs143/

Then we modify and add the constraints to enforce the data integerity.

By Zixia Weng, Shunji Zhan on Oct.16.2017
